import { useState, useEffect } from 'react'
import Layout from '../components/Layout/Layout'
import PageTitle from '../components/common/PageTitle'
import DataTable from '../components/common/DataTable'
import { userTableService } from '../services/userTableService'

const fmt = n => n>=1e6?(n/1e6).toFixed(1)+' M':n>=1e3?(n/1e3).toFixed(1)+' K':n

const CARDS = [
  { key:'vlowcount', icon:'assessment', label:'Very Low', grad:'linear-gradient(60deg,#66bb6a,#43a047)' },
  { key:'lowcount', icon:'pie_chart', label:'Low', grad:'linear-gradient(60deg,#26c6da,#0288d1)' },
  { key:'mediumcount', icon:'description', label:'Medium', grad:'linear-gradient(60deg,#bdbdbd,#9e9e9e)' },
  { key:'highcount', icon:'menu', label:'High', grad:'linear-gradient(60deg,#ffa726,#fb8c00)' },
  { key:'complexcount', icon:'timer', label:'Complex', grad:'linear-gradient(60deg,#ef5350,#e53935)' }
]

const COLS = [
  { key:'Object_Name', label:'Table Name' },
  { key:'Column_Count', label:'Column Count' },
  { key:'Row_Count', label:'Row Count', render: v => fmt(v) },
  { key:'Constraint_Count', label:'Constraint Count' },
  { key:'Index_Count', label:'Index Count' },
  { key:'Complexity', label:'Complexity', render: v => {
    const colors = { Low:'#28A745', 'Very Low':'#00AEEF', Medium:'#ffa726', High:'#E40521', Complex:'#900012' }
    return <span style={{ background: colors[v]+'22', color: colors[v], padding:'2px 8px', borderRadius:20, fontSize:11, fontWeight:600 }}>{v}</span>
  }}
]

export default function UserTable() {
  const [complexity, setComplexity] = useState({})
  const [rows, setRows] = useState([])

  useEffect(() => {
    userTableService.getComplexity().then(r => setComplexity(Array.isArray(r) ? r[0] : r))
    userTableService.getTableData().then(setRows)
  }, [])

  return (
    <Layout title="User Table Inventory">
      <PageTitle title="User Table Inventory" badge="Assessment" />
      <div style={{ display:'flex', gap:10, marginBottom:16 }}>
        {CARDS.map(c => (
          <div key={c.key} style={{ flex:1, borderRadius:10, overflow:'hidden', border:'1.5px solid #B5D4F4', boxShadow:'0 2px 14px rgba(18,35,79,.10)', background:'#fff' }}>
            <div style={{ background:c.grad, padding:'12px 12px 3px' }}>
              <div style={{ width:36,height:36,borderRadius:8,background:'rgba(255,255,255,.2)',display:'flex',alignItems:'center',justifyContent:'center' }}>
                <i className="material-icons" style={{ color:'#fff', fontSize:20 }}>{c.icon}</i>
              </div>
            </div>
            <div style={{ padding:'6px 12px 14px' }}>
              <div style={{ fontSize:20, fontWeight:700, color:'#12234F' }}>{complexity[c.key]||0}</div>
              <div style={{ fontSize:10, color:'#6B7A8D', fontWeight:600, textTransform:'uppercase', letterSpacing:.5 }}>{c.label}</div>
            </div>
          </div>
        ))}
      </div>
      <div className="cap-card">
        <div className="cap-card-header"><h4>User Table Inventory</h4></div>
        <div className="cap-card-body">
          <DataTable columns={COLS} data={rows} />
        </div>
      </div>
    </Layout>
  )
}
