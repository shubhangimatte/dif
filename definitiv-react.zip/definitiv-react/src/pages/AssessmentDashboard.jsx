import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import Layout from '../components/Layout/Layout'
import PageTitle from '../components/common/PageTitle'
import { assessmentService } from '../services/assessmentService'

const fmt = n => n>=1e9?(n/1e9).toFixed(1)+' B':n>=1e6?(n/1e6).toFixed(1)+' M':n>=1e3?(n/1e3).toFixed(1)+' K':String(n||0)
const fmtMB = n => { const v=parseFloat(n||0); return v>=1048576?(v/1048576).toFixed(1)+' TB':v>=1024?(v/1024).toFixed(1)+' GB':Math.round(v)+' MB' }

// 8 stat cards matching assesment_dashboard.php
const CARDS = [
  { key:'tablesCount',    icon:'table_chart', label:'Tables',       accent:'#0F766E', iconBg:'#CCFBF1', iconColor:'#0F766E', border:'#99F6E4' },
  { key:'fieldCount',     icon:'view_column', label:'Fields',       accent:'#047857', iconBg:'#D1FAE5', iconColor:'#047857', border:'#6EE7B7' },
  { key:'datatypeCount',  icon:'category',    label:'Data Types',   accent:'#B45309', iconBg:'#FEF3C7', iconColor:'#B45309', border:'#FCD34D' },
  { key:'storedproCount', icon:'code',        label:'Stored Procs', accent:'#7C3AED', iconBg:'#EDE9FE', iconColor:'#7C3AED', border:'#C4B5FD' },
  { key:'funCount',       icon:'functions',   label:'Functions',    accent:'#BE185D', iconBg:'#FCE7F3', iconColor:'#BE185D', border:'#F9A8D4' },
  { key:'viewCount',      icon:'visibility',  label:'Views',        accent:'#3730A3', iconBg:'#EDE9FE', iconColor:'#3730A3', border:'#C4B5FD' },
  { key:'rowSum',         icon:'timer',       label:'DB Records',   accent:'#0891B2', iconBg:'#CFFAFE', iconColor:'#0891B2', border:'#67E8F9' },
  { key:'dbSum',          icon:'storage',     label:'DB Size',      accent:'#475569', iconBg:'#F1F5F9', iconColor:'#475569', border:'#CBD5E1' },
]

// Complexity badge colors
const BADGE = { 'Very Low':'#0891B2', 'Low':'#0F766E', 'Medium':'#B45309', 'High':'#BE185D', 'Complex':'#7C3AED' }

function StatCard({ card, value }) {
  return (
    <div style={{
      flex:1, background:'#fff', borderRadius:12,
      border:`1.5px solid ${card.border}`,
      borderTop:`3px solid ${card.accent}`,
      boxShadow:'0 2px 10px rgba(0,0,0,.06)',
      transition:'transform .2s, box-shadow .2s', cursor:'default'
    }}
    onMouseEnter={e=>{e.currentTarget.style.transform='translateY(-3px)';e.currentTarget.style.boxShadow='0 8px 22px rgba(0,0,0,.12)'}}
    onMouseLeave={e=>{e.currentTarget.style.transform='';e.currentTarget.style.boxShadow='0 2px 10px rgba(0,0,0,.06)'}}>
      <div style={{ padding:'14px 14px 4px' }}>
        <div style={{ width:42,height:42,borderRadius:10,background:card.iconBg,display:'flex',alignItems:'center',justifyContent:'center' }}>
          <i className="material-icons" style={{ fontSize:22, color:card.iconColor }}>{card.icon}</i>
        </div>
      </div>
      <div style={{ padding:'4px 14px 16px' }}>
        <div style={{ fontSize:26, fontWeight:700, color:'#1E293B', letterSpacing:'-.5px' }}>{value}</div>
        <div style={{ fontSize:10.5, color:'#64748B', fontWeight:600, textTransform:'uppercase', letterSpacing:'.6px', marginTop:2 }}>{card.label}</div>
      </div>
    </div>
  )
}

export default function AssessmentDashboard() {
  const { dbId } = useParams()
  const navigate = useNavigate()
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    assessmentService.getData(dbId || 1)
      .then(setData)
      .finally(() => setLoading(false))
  }, [dbId])

  if (loading) return (
    <Layout title="Assessment Dashboard">
      <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:300, color:'#64748B' }}>
        <i className="material-icons" style={{ fontSize:36, marginRight:10, color:'#0070AD' }}>hourglass_top</i>
        Loading assessment data...
      </div>
    </Layout>
  )

  const s = data?.summary || {}
  const rows = data?.complexity || []

  return (
    <Layout title="Assessment Dashboard">

      {/* Back button */}
      <div style={{ marginBottom:12 }}>
        <button
          onClick={() => navigate('/')}
          style={{ display:'inline-flex', alignItems:'center', gap:5, background:'none', border:'1.5px solid #B5D4F4', borderRadius:7, padding:'6px 14px', fontSize:12.5, fontWeight:600, color:'#0070AD', cursor:'pointer' }}>
          <i className="material-icons" style={{ fontSize:16 }}>arrow_back</i> Back to Dashboard
        </button>
      </div>

      <PageTitle title={data?.dbname || 'Assessment Dashboard'} badge="Assessment" />

      {/* Stat cards row 1 */}
      <div style={{ display:'flex', gap:10, marginBottom:10 }}>
        {CARDS.slice(0,4).map(c => (
          <StatCard key={c.key} card={c} value={c.key==='dbSum' ? fmtMB(s[c.key]) : fmt(s[c.key])} />
        ))}
      </div>

      {/* Stat cards row 2 */}
      <div style={{ display:'flex', gap:10, marginBottom:20 }}>
        {CARDS.slice(4).map(c => (
          <StatCard key={c.key} card={c} value={c.key==='dbSum' ? fmtMB(s[c.key]) : fmt(s[c.key])} />
        ))}
      </div>

      {/* Complexity Analysis table */}
      <div style={{ background:'#fff', borderRadius:12, border:'0.5px solid #DDE8F4', boxShadow:'0 4px 20px rgba(18,35,79,.08)', overflow:'hidden' }}>

        {/* Table card header — Capgemini navy */}
        <div style={{ background:'linear-gradient(135deg,#12234F,#0070AD)', padding:'14px 22px' }}>
          <h4 style={{ fontSize:15, fontWeight:700, color:'#fff', margin:0 }}>
            {data?.dbname} — Complexity Analysis
          </h4>
        </div>

        {/* Table */}
        <div style={{ padding:'0', overflowX:'auto' }}>
          <table style={{ width:'100%', borderCollapse:'collapse' }}>
            <thead>
              <tr>
                {['Name','Total Count','Very Low','Low','Medium','High','Complex'].map(h => (
                  <th key={h} style={{ background:'#F0F4F8', color:'#12234F', fontSize:12, fontWeight:700, borderBottom:'2px solid #0070AD', padding:'10px 14px', textAlign: h==='Name'?'left':'center', letterSpacing:'.3px' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => (
                <tr key={row.name} style={{ background: i%2===0?'#F7FAFD':'#fff' }}>
                  <td style={{ padding:'10px 14px', fontSize:13, fontWeight:600, color:'#12234F', borderBottom:'1px solid #EAF0F8', display:'flex', alignItems:'center', gap:8 }}>
                    <i className="material-icons" style={{ fontSize:16, color:'#0070AD' }}>
                      {row.name==='Tables'?'table_chart':row.name==='Views'?'visibility':row.name==='Functions'?'functions':row.name==='Procedures'?'code':'flash_on'}
                    </i>
                    {row.name}
                  </td>
                  <td style={{ padding:'10px 14px', fontSize:13, fontWeight:700, color:'#1E293B', textAlign:'center', borderBottom:'1px solid #EAF0F8' }}>{row.total_count}</td>
                  {[
                    { key:'vlowcount',    label:'Very Low',  color:BADGE['Very Low']  },
                    { key:'lowcount',     label:'Low',       color:BADGE['Low']       },
                    { key:'mediumcount',  label:'Medium',    color:BADGE['Medium']    },
                    { key:'highcount',    label:'High',      color:BADGE['High']      },
                    { key:'complexcount', label:'Complex',   color:BADGE['Complex']   },
                  ].map(({ key, label, color }) => (
                    <td key={key} style={{ padding:'10px 14px', textAlign:'center', borderBottom:'1px solid #EAF0F8' }}>
                      <span style={{ background:`${color}18`, color, padding:'3px 10px', borderRadius:20, fontSize:12, fontWeight:600, display:'inline-block', minWidth:36 }}>
                        {row[key]}
                      </span>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>

            {/* Totals row */}
            <tfoot>
              <tr style={{ background:'#EEF3F9' }}>
                <td style={{ padding:'10px 14px', fontSize:12.5, fontWeight:700, color:'#12234F', borderTop:'2px solid #0070AD' }}>Total</td>
                {['total_count','vlowcount','lowcount','mediumcount','highcount','complexcount'].map(k => (
                  <td key={k} style={{ padding:'10px 14px', textAlign:'center', fontSize:13, fontWeight:700, color:'#12234F', borderTop:'2px solid #0070AD' }}>
                    {rows.reduce((s,r) => s + (r[k]||0), 0)}
                  </td>
                ))}
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

    </Layout>
  )
}
