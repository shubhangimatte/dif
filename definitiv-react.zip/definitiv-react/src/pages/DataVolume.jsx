import { useState, useEffect } from 'react'
import Layout from '../components/Layout/Layout'
import PageTitle from '../components/common/PageTitle'
import DataTable from '../components/common/DataTable'
import { dataVolumeService } from '../services/dataVolumeService'

const fmtMB = n => { const v=parseFloat(n); return v>=1048576?(v/1048576).toFixed(2)+' TB':v>=1024?(v/1024).toFixed(2)+' GB':Math.round(v)+' MB' }

const CARDS = [
  { key:'top10', icon:'bookmark', label:'Top 10 Tables Volume', grad:'linear-gradient(60deg,#66bb6a,#43a047)', fmt:fmtMB },
  { key:'top25', icon:'assessment', label:'Top 25 Tables Volume', grad:'linear-gradient(60deg,#26c6da,#00acc1)', fmt:fmtMB },
  { key:'50percentdata', icon:'pie_chart', label:'50% Data Volume Tables', grad:'linear-gradient(60deg,#26c6da,#0288d1)', fmt:n=>n },
  { key:'1to10MB', icon:'description', label:'1 MB – 10 MB Tables', grad:'linear-gradient(60deg,#bdbdbd,#9e9e9e)', fmt:n=>n },
  { key:'10to100MB', icon:'menu', label:'10 MB – 100 MB Tables', grad:'linear-gradient(60deg,#ffa726,#fb8c00)', fmt:n=>n }
]
const CARDS2 = [
  { key:'100to1GB', icon:'timer', label:'100 MB – 1 GB Tables', grad:'linear-gradient(60deg,#ef5350,#e53935)', fmt:n=>n },
  { key:'1GBto10GB', icon:'cloud', label:'1 GB – 10 GB Tables', grad:'linear-gradient(60deg,#66bb6a,#43a047)', fmt:n=>n },
  { key:'10GBto50GB', icon:'insert_chart', label:'10 GB – 50 GB Tables', grad:'linear-gradient(60deg,#ffa726,#fb8c00)', fmt:n=>n },
  { key:'50GBto100GB', icon:'storage', label:'50 GB – 100 GB Tables', grad:'linear-gradient(60deg,#bdbdbd,#9e9e9e)', fmt:n=>n },
  { key:'greaterThan100GB', icon:'settings', label:'> 100 GB Tables', grad:'linear-gradient(60deg,#ffa726,#fb8c00)', fmt:n=>n }
]

function CardRow({ cards, data }) {
  return (
    <div style={{ display:'flex', gap:10, marginBottom:12 }}>
      {cards.map(c => (
        <div key={c.key} style={{ flex:1, borderRadius:10, overflow:'hidden', border:'1.5px solid #B5D4F4', boxShadow:'0 2px 14px rgba(18,35,79,.10)', background:'#fff' }}>
          <div style={{ background:c.grad, padding:'12px 12px 3px' }}>
            <div style={{ width:36,height:36,borderRadius:8,background:'rgba(255,255,255,.2)',display:'flex',alignItems:'center',justifyContent:'center' }}>
              <i className="material-icons" style={{ color:'#fff', fontSize:20 }}>{c.icon}</i>
            </div>
          </div>
          <div style={{ padding:'6px 12px 14px' }}>
            <div style={{ fontSize:20, fontWeight:700, color:'#12234F' }}>{c.fmt(data[c.key]||0)}</div>
            <div style={{ fontSize:10, color:'#6B7A8D', fontWeight:600, textTransform:'uppercase', letterSpacing:.5 }}>{c.label}</div>
          </div>
        </div>
      ))}
    </div>
  )
}

const COLS = [
  { key:'Table_Name', label:'Table Name' },
  { key:'Size_MB', label:'Size', render: v => fmtMB(v) }
]

export default function DataVolume() {
  const [summary, setSummary] = useState({})
  const [rows, setRows] = useState([])

  useEffect(() => {
    dataVolumeService.getSummary().then(setSummary)
    dataVolumeService.getTableData().then(setRows)
  }, [])

  return (
    <Layout title="Data Volume">
      <PageTitle title="Data Volume" badge="Analysis" />
      <CardRow cards={CARDS} data={summary} />
      <CardRow cards={CARDS2} data={summary} />
      <div className="cap-card">
        <div className="cap-card-header"><h4>Data Volume</h4></div>
        <div className="cap-card-body">
          <DataTable columns={COLS} data={rows} />
        </div>
      </div>
    </Layout>
  )
}
