import api from '../api/api'
import axios from 'axios'

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost/Definitiv'

export const importService = {

  getInstances: async () => {
    try { return await api.get('/Importdboutputreport/getInstances') }
    catch { return [{ id:1, name:'Oracle' },{ id:2, name:'SQL Server' },{ id:3, name:'PostgreSQL' },{ id:4, name:'MySQL' }] }
  },

  // Existing: POST Importdboutputreport/import  (multipart form)
  importFile: (formData, onProgress) =>
    axios.post(`${BASE_URL}/Importdboutputreport/import`, formData, {
      withCredentials: true,
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: e => onProgress?.(Math.round(e.loaded * 100 / e.total))
    }).then(r => r.data),

  // Existing: GET Importdboutputreport/Delete_All
  deleteAll: () => api.get('/Importdboutputreport/Delete_All')
}
