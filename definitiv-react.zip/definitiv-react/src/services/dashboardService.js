import api from '../api/api'

// Real PHP endpoints that already return JSON
export const dashboardService = {

  // Existing: POST Dashboard/updateDatabase — returns source/target/db info
  updateDatabase: (projectId, env) =>
    api.post('/Dashboard/updateDatabase/', { project_id: projectId, env }),

  // Existing: POST Dashboard/getEnvidOptions — returns env dropdown options
  getEnvOptions: (projectId) =>
    api.post('/Dashboard/getEnvidOptions/', { project_id: projectId }),

  // ── No JSON endpoint yet — mock until API is ready ──
  getSummary: async () => ({
    dbCount: 12, tablesCount: 2418, fieldCount: 18743,
    datatypeCount: 94, storedproCount: 312, funCount: 87,
    rowSum: 4200000, dbSum: 141312
  }),

  getComplexity: async () => ({
    vlowcount: 24, lowcount: 58, mediumcount: 72, highcount: 41, complexcount: 17
  }),

  getDatabases: async () => ([
    { id: 1, name: 'PROD_ORACLE_MAIN', complexity: 'Medium',
      tables: 347, viewcount: 82, functions: '41 (12K)',
      storedprocedure: '93 (38K)', dbsize: '42.3 GB',
      dbsummary: { complex_datatype: 14, tbl_lowcomplexity: 128, tbl_mediumcomplexity: 93, tbl_highcomplexity: 17, dashboardtop10: '31.4 GB' }
    },
    { id: 2, name: 'DEV_SQLSERVER_HR', complexity: 'Low', tables: 124, viewcount: 18, functions: '12 (3K)', storedprocedure: '24 (8K)', dbsize: '8.1 GB', dbsummary: {} },
    { id: 3, name: 'UAT_POSTGRES_FINANCE', complexity: 'High', tables: 289, viewcount: 44, functions: '38 (15K)', storedprocedure: '71 (22K)', dbsize: '31.2 GB', dbsummary: {} }
  ]),

  getMigrationProjects: async () => ([])
}
