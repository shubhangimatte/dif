import api from '../api/api'

export const realtimeService = {

  getInstances: async () => {
    try { return await api.get('/RealtimeExtraction/getInstances') }
    catch { return [{ id:1, name:'Oracle' },{ id:2, name:'SQL Server' },{ id:3, name:'PostgreSQL' },{ id:4, name:'MySQL' }] }
  },

  // Existing: POST RealtimeExtraction/extraction  action=testconn
  testConnection: (data) =>
    api.post('/RealtimeExtraction/extraction', { ...data, action: 'testconn' }),

  // Existing: POST RealtimeExtraction/extraction  action=scan
  scanDatabase: (data) =>
    api.post('/RealtimeExtraction/extraction', { ...data, action: 'scan' })
}
