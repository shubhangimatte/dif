import api from '../api/api'

const MOCK_TABLES = [
  { Table_Name: 'ORDERS' }, { Table_Name: 'CUSTOMERS' },
  { Table_Name: 'TRANSACTIONS' }, { Table_Name: 'PRODUCTS' }
]

export const tableFieldService = {

  getTables: async () => {
    try { return await api.get('/TableFieldListing/getTables') }
    catch { return MOCK_TABLES }
  },

  // Existing: POST TableFieldListing/getTableData
  getTableFields: (tableName) =>
    api.post('/TableFieldListing/getTableData', { Table_Name: tableName }),

  // Existing: GET TableFieldListing/printAllData
  printAllData: () => api.get('/TableFieldListing/printAllData')
}
