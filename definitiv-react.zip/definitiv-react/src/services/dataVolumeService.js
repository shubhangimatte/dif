import api from '../api/api'

export const dataVolumeService = {
  getSummary: async () => {
    try { return await api.get('/DataVolume/getSummary') }
    catch {
      return {
        top10: 43315, top25: 79872, '50percentdata': 312,
        '1to10MB': 847, '10to100MB': 203, '100to1GB': 64,
        '1GBto10GB': 18, '10GBto50GB': 7, '50GBto100GB': 3, greaterThan100GB: 1
      }
    }
  },
  getTableData: async () => {
    try { return await api.get('/DataVolume/getTableData') }
    catch { return [{ Table_Name: 'ORDERS', Size_MB: 43315 }, { Table_Name: 'CUSTOMERS', Size_MB: 19149 }, { Table_Name: 'TRANSACTIONS', Size_MB: 9625 }] }
  }
}
