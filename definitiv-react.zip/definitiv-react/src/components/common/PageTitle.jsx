export default function PageTitle({ title, badge }) {
  return (
    <div className="page-title-wrap">
      <h4>{title}</h4>
      {badge && <span className="page-badge">{badge}</span>}
    </div>
  )
}
