import { Link, useNavigate } from 'react-router-dom'

export default function Navbar({ title = 'Dashboard' }) {
  const navigate = useNavigate()
  return (
    <nav className="cap-navbar">
      <Link to="/" className="cap-logo-pill" style={{ textDecoration: 'none' }}>
        <span className="cap-logo-brand">Capgemini</span>
        <span className="cap-logo-dot" />
        <span className="cap-logo-product">Database Assessment</span>
      </Link>
      <div className="cap-nav-sep" />
      <span className="cap-nav-title">{title.toUpperCase()}</span>
      <div className="cap-nav-right">
        <span className="cap-nav-welcome">
          <i className="material-icons" style={{ fontSize: 14, verticalAlign: 'middle', marginRight: 3 }}>person_outline</i>
          Welcome, Admin
        </span>
        <button className="cap-nav-btn" onClick={() => navigate('/')}>
          <i className="material-icons">dashboard</i>
          <span>Dashboard</span>
        </button>
        <button className="cap-nav-btn">
          <i className="material-icons">logout</i>
          <span>Logout</span>
        </button>
      </div>
    </nav>
  )
}
