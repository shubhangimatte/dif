import Navbar from './Navbar'
import Sidebar from './Sidebar'

export default function Layout({ children, title }) {
  return (
    <div className="wrapper">
      <Sidebar />
      <div className="main-panel">
        <Navbar title={title} />
        <div className="content">{children}</div>
      </div>
    </div>
  )
}
