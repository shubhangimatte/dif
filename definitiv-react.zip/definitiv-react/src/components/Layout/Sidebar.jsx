import { NavLink } from 'react-router-dom'

const menu = [
  { section: 'Main' },
  { to: '/', icon: 'dashboard', label: 'Dashboard', end: true },
  { section: 'Assessment' },
  { to: '/assessment/1', icon: 'analytics', label: 'Assessment Dashboard' },
  { to: '/data-volume', icon: 'storage', label: 'Data Volume' },
  { to: '/user-table', icon: 'table_chart', label: 'User Tables' },
  { to: '/table-fields', icon: 'view_list', label: 'Table Fields' },
  { section: 'Extraction' },
  { to: '/realtime-extraction', icon: 'cable', label: 'Realtime Extraction' },
  { to: '/import-report', icon: 'upload_file', label: 'Import DB Report' },
]

export default function Sidebar() {
  return (
    <div className="cap-sidebar">
      <NavLink to="/" className="sb-logo" style={{ textDecoration: 'none' }}>
        <div className="sb-logo-box">
          <span style={{ fontSize: 10, fontWeight: 700, color: '#0070AD' }}>CAP</span>
        </div>
        <div className="sb-logo-text">
          <span className="sb-name">Database Assessment</span>
          <span className="sb-sub">by Capgemini</span>
        </div>
      </NavLink>

      {menu.map((item, i) =>
        item.section
          ? <div key={i} className="sb-section">{item.section}</div>
          : (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end || false}
              className={({ isActive }) => `sb-item${isActive ? ' active' : ''}`}
              style={{ textDecoration: 'none' }}
            >
              <i className="material-icons">{item.icon}</i>
              {item.label}
            </NavLink>
          )
      )}
    </div>
  )
}
