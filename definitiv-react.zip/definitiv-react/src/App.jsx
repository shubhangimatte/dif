import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import './styles/capgemini.css'
import Dashboard from './pages/Dashboard'
import DataVolume from './pages/DataVolume'
import UserTable from './pages/UserTable'
import RealtimeExtraction from './pages/RealtimeExtraction'
import ImportDBReport from './pages/ImportDBReport'
import TableFieldListing from './pages/TableFieldListing'
import AssessmentDashboard from './pages/AssessmentDashboard'

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/assessment/:dbId" element={<AssessmentDashboard />} />
        <Route path="/data-volume" element={<DataVolume />} />
        <Route path="/user-table" element={<UserTable />} />
        <Route path="/realtime-extraction" element={<RealtimeExtraction />} />
        <Route path="/import-report" element={<ImportDBReport />} />
        <Route path="/table-fields" element={<TableFieldListing />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </BrowserRouter>
  )
}
